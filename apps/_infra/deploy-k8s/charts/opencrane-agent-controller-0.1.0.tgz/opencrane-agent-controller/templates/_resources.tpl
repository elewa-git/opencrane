{{- define "opencrane.agentController.resources" -}}
{{- if .Values.agentController.enabled }}
{{- if not .Values.agentRuntime.enabled }}
{{- fail "agentRuntime.enabled must be true when agentController.enabled=true" }}
{{- end }}
{{- $fullName := include "opencrane.fullname" . -}}
{{- $namespace := default .Release.Namespace .Values.agentController.namespace -}}
{{- $runtimeNamespace := default .Release.Namespace .Values.agentRuntime.namespace -}}
{{- if ne $namespace $runtimeNamespace }}
{{- fail "agentRuntime.namespace must equal agentController.namespace while the controller is namespaced" }}
{{- end }}
{{- $openCraneInternalUrl := .Values.agentController.openCraneInternalUrl | default (printf "http://%s-opencrane-server.%s.svc.cluster.local:%v" $fullName .Release.Namespace .Values.clustertenantManager.service.internalPort) -}}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ $fullName }}-agent-controller
  namespace: {{ $namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: agent-controller
automountServiceAccountToken: false
---
# The controller may create, observe, suspend, and delete only its owned Job objects.
# It cannot read Secrets, authenticate other workloads, or mutate any other resource type.
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: {{ $fullName }}-agent-controller
  namespace: {{ $namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: agent-controller
rules:
  - apiGroups: ["batch"]
    resources: ["jobs"]
    verbs: ["get", "list", "watch", "create", "patch", "delete"]
  - apiGroups: [""]
    resources: ["pods"]
    verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: {{ $fullName }}-agent-controller
  namespace: {{ $namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: agent-controller
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: {{ $fullName }}-agent-controller
subjects:
  - kind: ServiceAccount
    name: {{ $fullName }}-agent-controller
    namespace: {{ $namespace }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ $fullName }}-agent-controller
  namespace: {{ $namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: agent-controller
spec:
  replicas: {{ .Values.agentController.replicas }}
  selector:
    matchLabels:
      {{- include "opencrane.selectorLabels" . | nindent 6 }}
      app.kubernetes.io/component: agent-controller
  template:
    metadata:
      labels:
        {{- include "opencrane.selectorLabels" . | nindent 8 }}
        app.kubernetes.io/component: agent-controller
    spec:
      serviceAccountName: {{ $fullName }}-agent-controller
      automountServiceAccountToken: false
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        runAsGroup: 1000
        fsGroup: 1000
        seccompProfile:
          type: RuntimeDefault
      containers:
        - name: agent-controller
          image: "{{ .Values.agentController.image.repository }}:{{ .Values.agentController.image.tag }}"
          imagePullPolicy: {{ .Values.agentController.image.pullPolicy }}
          ports:
            - name: health
              containerPort: {{ .Values.agentController.healthPort }}
              protocol: TCP
          securityContext:
            allowPrivilegeEscalation: false
            capabilities:
              drop: ["ALL"]
            readOnlyRootFilesystem: true
          env:
            - name: OPENCRANE_INTERNAL_URL
              value: {{ $openCraneInternalUrl | quote }}
            - name: AGENT_CONTROLLER_WORKLOAD_NAMESPACE
              value: {{ $namespace | quote }}
            - name: AGENT_CONTROLLER_KUBERNETES_TOKEN_PATH
              value: /var/run/opencrane/tokens/kubernetes/token
            - name: AGENT_CONTROLLER_KUBERNETES_CA_PATH
              value: /var/run/opencrane/tokens/kubernetes/ca.crt
            - name: AGENT_CONTROLLER_OPENCRANE_TOKEN_PATH
              value: /var/run/opencrane/tokens/opencrane/token
            - name: AGENT_RUNTIME_SERVICE_ACCOUNT
              value: {{ required "agentRuntime.serviceAccountName is required when agentController.enabled=true" .Values.agentRuntime.serviceAccountName | quote }}
            - name: AGENT_RUNTIME_APP_NAME
              value: {{ include "opencrane.name" . | quote }}
            - name: AGENT_RUNTIME_RELEASE_INSTANCE
              value: {{ .Release.Name | quote }}
            - name: AGENT_RUNTIME_IMAGE
              value: {{ required "agentController.runtimeImage is required when agentController.enabled=true" .Values.agentController.runtimeImage | quote }}
            - name: AGENT_RUNTIME_PROJECTED_TOKEN_TTL_SECONDS
              value: {{ .Values.agentRuntime.projectedTokenTtlSeconds | quote }}
            - name: AGENT_CONTROLLER_POLL_INTERVAL_MS
              value: {{ .Values.agentController.pollIntervalMs | quote }}
            - name: AGENT_CONTROLLER_HEALTH_PORT
              value: {{ .Values.agentController.healthPort | quote }}
            {{- include "opencrane.observabilityEnv" (dict "ctx" $ "component" "agent-controller") | nindent 12 }}
          volumeMounts:
            - name: kubernetes-api-token
              mountPath: /var/run/opencrane/tokens/kubernetes
              readOnly: true
            - name: opencrane-token
              mountPath: /var/run/opencrane/tokens/opencrane
              readOnly: true
          resources:
            {{- toYaml .Values.agentController.resources | nindent 12 }}
          readinessProbe:
            httpGet:
              path: /readyz
              port: health
            initialDelaySeconds: 1
            periodSeconds: 5
            timeoutSeconds: 1
            failureThreshold: 3
          livenessProbe:
            httpGet:
              path: /livez
              port: health
            initialDelaySeconds: 1
            periodSeconds: 10
            timeoutSeconds: 1
            failureThreshold: 3
      volumes:
        # This token is only for the Kubernetes API. Its audience differs from the
        # server token below, so a token accepted by one authority is useless to the other.
        - name: kubernetes-api-token
          projected:
            defaultMode: 0440
            sources:
              - serviceAccountToken:
                  path: token
                  audience: https://kubernetes.default.svc
                  expirationSeconds: {{ .Values.agentController.projectedTokenTtlSeconds }}
              - configMap:
                  # Kubernetes creates this namespace-local trust bundle. It lets the controller
                  # verify the API server while still keeping the API audience token explicit.
                  name: kube-root-ca.crt
                  items:
                    - key: ca.crt
                      path: ca.crt
        - name: opencrane-token
          projected:
            defaultMode: 0440
            sources:
              - serviceAccountToken:
                  path: token
                  audience: agent-controller
                  expirationSeconds: {{ .Values.agentController.projectedTokenTtlSeconds }}
---
# The controller has no inbound API. Egress is constrained to its two required
# authorities: Kubernetes Jobs/Pods and the OpenCrane internal listener, plus DNS/telemetry.
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: {{ $fullName }}-agent-controller
  namespace: {{ $namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: agent-controller
spec:
  podSelector:
    matchLabels:
      {{- include "opencrane.selectorLabels" . | nindent 6 }}
      app.kubernetes.io/component: agent-controller
  policyTypes: ["Ingress", "Egress"]
  ingress: []
  egress:
    # Service traffic cannot be selected by NetworkPolicy. Operators explicitly provide
    # the API-server CIDR for their cluster instead of silently allowing all HTTPS egress.
    - to:
        - ipBlock:
            cidr: {{ required "agentController.kubernetesApi.cidr is required when agentController.enabled=true" .Values.agentController.kubernetesApi.cidr | quote }}
      ports:
        - protocol: TCP
          port: {{ .Values.agentController.kubernetesApi.port | default 443 }}
    - to:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: {{ .Release.Namespace }}
          podSelector:
            matchLabels:
              {{- include "opencrane.selectorLabels" . | nindent 14 }}
              app.kubernetes.io/component: opencrane-server
      ports:
        - protocol: TCP
          port: {{ .Values.clustertenantManager.service.internalPort }}
    - to:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: kube-system
          podSelector:
            matchLabels:
              k8s-app: kube-dns
      ports:
        - protocol: UDP
          port: 53
        - protocol: TCP
          port: 53
    {{- if .Values.observability.otel.enabled }}
    - to:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: {{ $namespace }}
          podSelector:
            matchLabels:
              app.kubernetes.io/component: otel-collector
      ports:
        - protocol: TCP
          port: {{ .Values.observability.otel.collector.otlpPort }}
    {{- end }}
---
# Bind controller egress to its Kubernetes-issued identity instead of a mutable workload label.
# The runtime ServiceAccount is deliberately absent: it never receives Kubernetes API egress.
apiVersion: cilium.io/v2
kind: CiliumNetworkPolicy
metadata:
  name: {{ $fullName }}-agent-controller
  namespace: {{ $namespace }}
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: agent-controller
spec:
  endpointSelector:
    matchLabels:
      "k8s:app.kubernetes.io/name": {{ include "opencrane.name" . | quote }}
      "k8s:app.kubernetes.io/instance": {{ .Release.Name | quote }}
      "k8s:app.kubernetes.io/component": agent-controller
      "io.cilium.k8s.policy.serviceaccount": {{ printf "%s-agent-controller" $fullName | quote }}
  egress:
    - toCIDR:
        - {{ required "agentController.kubernetesApi.cidr is required when agentController.enabled=true" .Values.agentController.kubernetesApi.cidr | quote }}
      toPorts:
        - ports:
            - port: {{ .Values.agentController.kubernetesApi.port | default 443 | quote }}
              protocol: TCP
    - toEndpoints:
        - matchLabels:
            "k8s:io.kubernetes.pod.namespace": {{ .Release.Namespace | quote }}
            "k8s:app.kubernetes.io/name": {{ include "opencrane.name" . | quote }}
            "k8s:app.kubernetes.io/instance": {{ .Release.Name | quote }}
            "k8s:app.kubernetes.io/component": opencrane-server
            "io.cilium.k8s.policy.serviceaccount": {{ printf "%s-opencrane-server" $fullName | quote }}
      toPorts:
        - ports:
            - port: {{ .Values.clustertenantManager.service.internalPort | quote }}
              protocol: TCP
    - toEndpoints:
        - matchLabels:
            "k8s:io.kubernetes.pod.namespace": kube-system
            "k8s:k8s-app": kube-dns
      toPorts:
        - ports:
            - port: "53"
              protocol: UDP
            - port: "53"
              protocol: TCP
    {{- if .Values.observability.otel.enabled }}
    - toEndpoints:
        - matchLabels:
            "k8s:io.kubernetes.pod.namespace": {{ $namespace | quote }}
            "k8s:app.kubernetes.io/component": otel-collector
      toPorts:
        - ports:
            - port: {{ .Values.observability.otel.collector.otlpPort | quote }}
              protocol: TCP
    {{- end }}
{{- end }}
{{- end }}
