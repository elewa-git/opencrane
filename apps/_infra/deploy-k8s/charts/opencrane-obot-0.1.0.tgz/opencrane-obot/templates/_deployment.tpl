{{- define "opencrane.obot.deployment" -}}
{{- /* Render the release-local Obot Deployment only when enabled AND instance-scoped.
       When sharedPlatform.mcpGateway.mode=shared the operator points tenants at an
       external Obot (opencrane.mcpGatewayUrl), so no in-release workload is created. */ -}}
{{- if and .Values.mcpGateway.enabled (ne (include "opencrane.mcpGatewayShared" .) "true") }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "opencrane.fullname" . }}-mcp-gateway
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: mcp-gateway
spec:
  replicas: {{ .Values.mcpGateway.replicas }}
  selector:
    matchLabels:
      {{- include "opencrane.selectorLabels" . | nindent 6 }}
      app.kubernetes.io/component: mcp-gateway
  template:
    metadata:
      labels:
        {{- include "opencrane.selectorLabels" . | nindent 8 }}
        app.kubernetes.io/component: mcp-gateway
      {{- with .Values.mcpGateway.podAnnotations }}
      annotations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
    spec:
      serviceAccountName: {{ include "opencrane.fullname" . }}-mcp-gateway
      automountServiceAccountToken: true
      securityContext:
        {{- toYaml .Values.mcpGateway.podSecurityContext | nindent 8 }}
      {{- if .Values.mcpGateway.encryptionAtRest.enabled }}
      # Encryption-at-rest setup (P0.3) — replicates obot v0.23.1's upstream
      # `encryptionsetup` init container (chart/templates/deployment.yaml). It writes the
      # apiserver EncryptionConfiguration that provider=custom requires, into a Memory-backed
      # emptyDir shared with the main container. The encrypted-resource list is copied
      # VERBATIM from upstream — a partial list would silently leave data unencrypted.
      initContainers:
        - name: encryptionsetup
          image: "{{ .Values.mcpGateway.image.repository }}:{{ .Values.mcpGateway.image.tag }}"
          imagePullPolicy: {{ .Values.mcpGateway.image.pullPolicy }}
          securityContext:
            {{- toYaml .Values.mcpGateway.securityContext | nindent 12 }}
          env:
            - name: OBOT_SERVER_ENCRYPTION_PROVIDER
              value: "custom"
            - name: OBOT_SERVER_ENCRYPTION_KEY
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.mcpGateway.encryptionAtRest.secretName }}
                  key: {{ .Values.mcpGateway.encryptionAtRest.secretKey }}
          command:
            - /bin/sh
            - -c
            - |
              provider="$(printf '%s' "${OBOT_SERVER_ENCRYPTION_PROVIDER}" | tr '[:upper:]' '[:lower:]')"
              if [ "${provider}" != "custom" ]; then
                exit 0
              fi
              if [ -z "${OBOT_SERVER_ENCRYPTION_KEY}" ]; then
                echo "OBOT_SERVER_ENCRYPTION_KEY must be set when OBOT_SERVER_ENCRYPTION_PROVIDER=custom" >&2
                exit 1
              fi
              cat > /config/encryption.yaml <<EOF
              kind: EncryptionConfiguration
              apiVersion: apiserver.config.k8s.io/v1
              resources:
                - resources:
                    - credentials.obot.obot.ai
                    - users.obot.obot.ai
                    - identities.obot.obot.ai
                    - mcpoauthtokens.obot.obot.ai
                    - mcpauditlogs.obot.obot.ai
                    - mcpoauthpendingstates.obot.obot.ai
                    - policyviolations.obot.obot.ai
                    - properties.obot.obot.ai
                  providers:
                    - aesgcm:
                        keys:
                          - name: key0
                            secret: "${OBOT_SERVER_ENCRYPTION_KEY}"
                    - identity: {}
              EOF
          volumeMounts:
            - name: obot-config
              mountPath: /config
      {{- end }}
      containers:
        - name: mcp-gateway
          image: "{{ .Values.mcpGateway.image.repository }}:{{ .Values.mcpGateway.image.tag }}"
          imagePullPolicy: {{ .Values.mcpGateway.image.pullPolicy }}
          securityContext:
            {{- toYaml .Values.mcpGateway.securityContext | nindent 12 }}
          {{- if .Values.mcpGateway.encryptionAtRest.enabled }}
          # Read the EncryptionConfiguration written by the init container (P0.3).
          volumeMounts:
            - name: obot-config
              mountPath: /config
          {{- end }}
          ports:
            - name: http
              containerPort: {{ .Values.mcpGateway.service.port }}
          env:
            # Database — Obot requires a PostgreSQL DSN. Provide via the per-instance,
            # release-prefixed `<fullname>-obot` Secret (B5: a fixed `opencrane-obot`
            # name would collide across instances in one cluster). Provisioned
            # out-of-band (operator/installer), not by this chart.
            - name: OBOT_SERVER_DSN
              valueFrom:
                secretKeyRef:
                  name: {{ include "opencrane.obotSecretName" . }}
                  key: dsn
            # Hostname — used by Obot for OAuth callbacks; set to the in-cluster service URL.
            - name: OBOT_SERVER_HOSTNAME
              value: "http://{{ include "opencrane.fullname" . }}-mcp-gateway.{{ .Release.Namespace }}.svc.cluster.local:{{ .Values.mcpGateway.service.port }}"
            {{- if ((.Values.mcpGateway.auth).enabled) }}
            # Authentication ENABLED (P0.1) — the prerequisite for per-user credentials +
            # MCP access policies (Obot can only differentiate users it authenticates).
            # Federating to OpenCrane's OIDC IdP is a one-time RUNTIME step (Obot has no
            # env-only OIDC provider): log in with the bootstrap token → configure an OIDC
            # auth provider → grant admins. See values.yaml `mcpGateway.auth`.
            - name: OBOT_SERVER_ENABLE_AUTHENTICATION
              value: "true"
            # Registry auth ON → /v0.1/servers returns per-user-accessible servers instead
            # of the default wildcard "everyone" access (the multi-tenant isolation gate).
            - name: OBOT_SERVER_ENABLE_REGISTRY_AUTH
              value: "true"
            {{- with .Values.mcpGateway.auth.adminEmails }}
            # Org/platform admins → Obot Admin role (tenant end-users stay Basic User).
            - name: OBOT_SERVER_AUTH_ADMIN_EMAILS
              value: {{ . | quote }}
            {{- end }}
            {{- with .Values.mcpGateway.auth.ownerEmails }}
            - name: OBOT_SERVER_AUTH_OWNER_EMAILS
              value: {{ . | quote }}
            {{- end }}
            {{- if .Values.mcpGateway.auth.bootstrapTokenSecret }}
            # Bootstrap token for the one-time admin login (>=8 chars). Omit the Secret to
            # let Obot autogenerate one (read it from the pod logs for first bootstrap).
            - name: OBOT_BOOTSTRAP_TOKEN
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.mcpGateway.auth.bootstrapTokenSecret }}
                  key: {{ .Values.mcpGateway.auth.bootstrapTokenSecretKey }}
            {{- end }}
            {{- else }}
            # Authentication DISABLED (default) — Obot is in-cluster only; access is gated by
            # NetworkPolicy. Shared-credential multi-user servers ONLY: per-user credentials
            # and per-user access policies are not possible until auth is enabled (P0.1).
            - name: OBOT_SERVER_ENABLE_AUTHENTICATION
              value: "false"
            {{- end }}
            # MCP runtime backend — run MCP server containers as Kubernetes pods.
            - name: OBOT_SERVER_MCPRUNTIME_BACKEND
              value: "kubernetes"
            - name: OBOT_SERVER_MCPCLUSTER_DOMAIN
              value: "cluster.local"
            - name: OBOT_SERVER_MCPNAMESPACE
              value: "{{ .Release.Namespace }}"
            - name: OBOT_SERVER_SERVICE_NAME
              value: "{{ include "opencrane.fullname" . }}-mcp-gateway"
            - name: OBOT_SERVER_SERVICE_NAMESPACE
              value: "{{ .Release.Namespace }}"
            - name: OBOT_SERVER_SERVICE_ACCOUNT_NAME
              valueFrom:
                fieldRef:
                  fieldPath: spec.serviceAccountName
            {{- if .Values.mcpGateway.encryptionAtRest.enabled }}
            # Encryption-at-rest ENABLED (P0.3). Confirmed against obot v0.23.1:
            # provider=custom makes the binary read an apiserver EncryptionConfiguration
            # FILE — it never consumes the bare key — so the `encryptionsetup` init
            # container below materialises /config/encryption.yaml from this key and we
            # point OBOT_SERVER_ENCRYPTION_CONFIG_FILE at it. Without both, the key is
            # necessary-but-insufficient and data is left unencrypted. Gated behind
            # mcpGateway.encryptionAtRest.enabled (default OFF).
            - name: OBOT_SERVER_ENCRYPTION_PROVIDER
              value: "custom"
            - name: OBOT_SERVER_ENCRYPTION_KEY
              valueFrom:
                secretKeyRef:
                  name: {{ .Values.mcpGateway.encryptionAtRest.secretName }}
                  key: {{ .Values.mcpGateway.encryptionAtRest.secretKey }}
            - name: OBOT_SERVER_ENCRYPTION_CONFIG_FILE
              value: "/config/encryption.yaml"
            {{- else }}
            # No credential encryption at rest (baseline; P0.3 default OFF).
            - name: OBOT_SERVER_ENCRYPTION_PROVIDER
              value: "none"
            {{- end }}
            {{- if ((.Values.mcpGateway.catalog).path) }}
            # Default MCP catalogue (P0.2) — a LOCAL FILESYSTEM directory of catalogue-entry
            # YAMLs that Obot loads for all users. This is Obot's real catalogue knob
            # (`default-mcpcatalog-path`), confirmed against obot v0.23.1 pkg/services/config.go.
            # GitOps: sync a catalogue git repo into this path (e.g. a git-sync sidecar), or —
            # once authentication is enabled — add Git Source URLs at runtime via Obot Admin.
            #
            # The retired provider-registry env was an LLM filesystem-directory setting, not an
            # MCP-catalogue transport. The local catalogue path above is the supported input.
            - name: OBOT_SERVER_DEFAULT_MCPCATALOG_PATH
              value: {{ (.Values.mcpGateway.catalog).path | quote }}
            {{- end }}
          livenessProbe:
            httpGet:
              path: /api/healthz
              port: http
            initialDelaySeconds: 20
            periodSeconds: 15
            failureThreshold: 4
          readinessProbe:
            httpGet:
              path: /api/healthz
              port: http
            initialDelaySeconds: 10
            periodSeconds: 10
          resources:
            {{- toYaml .Values.mcpGateway.resources | nindent 12 }}
      {{- if .Values.mcpGateway.encryptionAtRest.enabled }}
      # Shared in-memory volume carrying the EncryptionConfiguration from the init
      # container to the main container (P0.3). Memory-backed so the rendered key
      # material never lands on disk.
      volumes:
        - name: obot-config
          emptyDir:
            medium: Memory
      {{- end }}
{{- end }}
{{- end }}
