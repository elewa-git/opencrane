{{- define "opencrane.server.ingress" -}}
{{- if .Values.ingress.enabled -}}
{{- /*
Fixed-wildcard topology: the control plane is the FIXED super-operator host, distinct
from the org-wildcard base (`ingress.domain`). It serves at `ingress.controlPlaneHost`
when set, else the derived default `platform.<ingress.domain>` — never under the org
wildcard `*.<ingress.domain>`. See docs/agents/cluster-architecture.md → "Tenancy Model".
*/ -}}
{{- $host := .Values.ingress.controlPlaneHost | default (printf "platform.%s" .Values.ingress.domain) -}}
{{- /* SPA backend for the `/` rule below: the chart-native Deployment/Service
       (opencrane-ui-spa-{deployment,service}.yaml) when controlPlaneSpa.enabled,
       else ingress.sameOrigin.spaService/spaPort unchanged (the external-Service seam
       from the "fall back / to opencrane-ui when no SPA is configured" fix). */ -}}
{{- $spaService := .Values.ingress.sameOrigin.spaService -}}
{{- $spaPort := .Values.ingress.sameOrigin.spaPort -}}
{{- if .Values.controlPlaneSpa.enabled -}}
{{- $spaService = printf "%s-opencrane-ui-spa" (include "opencrane.fullname" .) -}}
{{- $spaPort = .Values.controlPlaneSpa.service.port -}}
{{- end -}}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ include "opencrane.fullname" . }}-opencrane-server
  labels:
    {{- include "opencrane.labels" . | nindent 4 }}
    app.kubernetes.io/component: opencrane-server
  {{- with .Values.ingress.annotations }}
  annotations:
    {{- toYaml . | nindent 4 }}
  {{- end }}
spec:
  {{- if .Values.ingress.className }}
  ingressClassName: {{ .Values.ingress.className }}
  {{- end }}
  {{- if .Values.ingress.tls.enabled }}
  tls:
    - hosts:
        - {{ $host | quote }}
      secretName: {{ .Values.ingress.tls.secretName | default "opencrane-wildcard-tls" }}
  {{- end }}
  rules:
    - host: {{ $host | quote }}
      http:
        paths:
          # Same-origin hosting: the OpenCrane API under /api, the bounded channel HTTP/SSE
          # endpoints under /v1, and the org-admin SPA under /. One origin gives the channel
          # proxy first-party session cookies without CORS. Helm OWNS these rules,
          # so the frontend layer never has to kubectl-patch the Ingress out-of-band (that
          # patch fought `helm upgrade` via an SSA field-manager conflict and reverted on
          # every reconcile — see docs/optimalisation-plan.md §5).
          - path: /api
            pathType: Prefix
            backend:
              service:
                name: {{ include "opencrane.fullname" . }}-opencrane-server
                port:
                  number: {{ .Values.clustertenantManager.service.port }}
          {{- if .Values.channelProxy.enabled }}
          - path: /v1/commands
            pathType: Exact
            backend:
              service:
                name: {{ include "opencrane.fullname" . }}-channel-proxy
                port:
                  number: {{ .Values.channelProxy.service.port }}
          - path: /v1/events
            pathType: Exact
            backend:
              service:
                name: {{ include "opencrane.fullname" . }}-channel-proxy
                port:
                  number: {{ .Values.channelProxy.service.port }}
          {{- end }}
          {{- if .Values.gatewayProxy.enabled }}
          - path: /gateway
            pathType: Prefix
            backend:
              service:
                name: {{ include "opencrane.fullname" . }}-gateway-proxy
                port:
                  number: {{ .Values.gatewayProxy.port }}
          {{- end }}
          # `/` → the org-admin SPA when one is configured (WeOwnAI/frontend deploys),
          # else the control plane itself — so a standalone/headless silo with no SPA
          # still serves `/` instead of 502ing. `/api` + `/gateway` are unconditional
          # either way; the removed legacy path was the `*.<domain>` wildcard, not this.
          - path: /
            pathType: Prefix
            backend:
              service:
                {{- if $spaService }}
                name: {{ $spaService }}
                port:
                  number: {{ $spaPort }}
                {{- else }}
                name: {{ include "opencrane.fullname" . }}-opencrane-server
                port:
                  number: {{ .Values.clustertenantManager.service.port }}
                {{- end }}
{{- end }}
{{- end }}
